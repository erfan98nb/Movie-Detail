<?xml version="1.0" encoding="UTF-8" standalone="no"?>
<document type="com.apple.InterfaceBuilder3.CocoaTouch.XIB" version="3.0" toolsVersion="13142" targetRuntime="iOS.CocoaTouch" propertyAccessControl="none" useAutolayout="YES" useTraitCollections="YES" useSafeAreas="YES" colorMatched="YES">
    <dependencies>
        <plugIn identifier="com.apple.InterfaceBuilder.IBCocoaTouchPlugin" version="12042"/>
    </dependencies>
    <objects>
        <placeholder placeholderIdentifier="IBFilesOwner" id="-1" userLabel="File's Owner"/>
        <placeholder placeholderIdentifier="IBFirstResponder" id="-2" customClass="UIResponder"/>
    </objects>
</document>
in this app only used networking Library such as :

1. Alamofire for make a network connection 
2. SwiftyJson for get and convert data from API
3. SDWebImage for load and display image

* support DarkMode and Lightmood
* in this project I used MVVM architecture
* code's are clean and readable

* this project has 3 folder (View , ViewModel, Model)
    * View: include ContentView , SearchBar and DetailView
        * ContentView : display list of movies and search names
        * SearchBar : this page is part of ContentView
        * DetailView : if user clicked on any item from the list  , the edtail's of the selected item display in this view  and include name , picture and overview of selected movie
  
    * ViewModel: MovieViewModel file used for get data from IPA  
    * Model: when we get data from MovieViewModel then DetailModel have to convert Json to readable content
