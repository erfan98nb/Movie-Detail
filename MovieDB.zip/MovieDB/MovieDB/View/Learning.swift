//
//  Learning.swift
//  MovieDB
//
//  Created by Macbook-Pro on 8/23/24.
//

import SwiftUI

struct Learning: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

#Preview {
    Learning()
}
